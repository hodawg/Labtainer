# net-https-identify

Bài Lab Labtainer: **Nhận diện lưu lượng HTTPS và cổng 443** (mức độ 1).
Đề tài: Xây dựng các bài Lab trên Labtainer để phát hiện & phân tích các giao thức kết nối mạng - Học viện Công nghệ Bưu chính Viễn thông, Khoa An toàn thông tin.

Sinh viên thực hiện: Đàm Hoàng Đăng (B22DCAT081). Giảng viên hướng dẫn: TS. Quản Trọng Thế.

## Cấu trúc

```
net-https-identify/
├── config/        start.config, results.config, goals.config, version
├── dockerfiles/   Dockerfile của hai container client và server
├── docs/          hướng dẫn thực hành
├── client/        tệp hướng dẫn trong thư mục home của client
└── server/        cấu hình nginx, trang web mẫu, script khởi động
```

## Cách sử dụng

1. Sao chép thư mục `net-https-identify` vào `labtainer/trunk/labs/` (hoặc `labtainer/labs/`) trên máy đã cài Labtainer.
2. Chạy bài Lab: `labtainer net-https-identify`
3. Kiểm tra: `checkwork net-https-identify`; kết thúc: `stoplab net-https-identify`.

Để đóng gói và phát hành (cần Docker và tài khoản Docker Hub): dùng `create-imodules.sh` để tạo `imodule.tar` và `publish.py` để đẩy ảnh lên Docker Hub, như trong mẫu bài Lab.
