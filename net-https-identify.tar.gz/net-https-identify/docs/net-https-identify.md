# Bài thực hành: Nhận diện lưu lượng HTTPS và cổng 443 (net-https-identify)

**Mức độ:** 1 (Cơ bản)  
**Sinh viên thực hiện:** Đàm Hoàng Đăng (B22DCAT081) - Học viện Công nghệ Bưu chính Viễn thông, Khoa An toàn thông tin  
**Giảng viên hướng dẫn:** TS. Quản Trọng Thế

## 1. Giới thiệu chung

Bài thực hành giúp người thực hành nhận biết lưu lượng HTTPS trong dữ liệu bắt được bằng Wireshark. Các đặc điểm nhận dạng gồm: kết nối TCP tới cổng 443, giao thức hiển thị là TLS và dữ liệu ứng dụng đã được mã hóa. Từ đó phân biệt được với lưu lượng HTTP trên cổng 80.

## 2. Mục đích

Nhận diện lưu lượng HTTPS thông qua cổng 443, giao thức TLS và các bản ghi dữ liệu đã mã hóa; phân biệt với lưu lượng HTTP.

## 3. Yêu cầu đối với người thực hành

Có kiến thức cơ bản về mô hình TCP/IP, giao thức HTTP/HTTPS; biết dùng dòng lệnh Linux cơ bản; đã làm quen giao diện Wireshark.

## 4. Nội dung thực hành

**Khởi động bài lab** (tại terminal): `labtainer net-https-identify`

Nhập địa chỉ email khi hệ thống yêu cầu (dùng khi chấm điểm). Hệ thống mở terminal cho máy `client` và máy `server`. Máy `server` chạy sẵn dịch vụ web trên cổng 80 (HTTP) và 443 (HTTPS, chứng chỉ tự ký).

**Bước 1. Bắt gói tin trên máy client:** `wireshark &` → chọn giao diện `eth0` → bắt đầu bắt gói tin.

**Bước 2. Tạo lưu lượng HTTPS:** `curl -k https://server` (tùy chọn `-k` bỏ qua cảnh báo chứng chỉ tự ký).

**Bước 3. Tạo lưu lượng HTTP để đối chiếu:** `curl http://server`

**Bước 4. Phân tích trên Wireshark:** dừng bắt gói tin rồi lần lượt dùng bộ lọc:

- `tcp.port == 443` — lưu lượng tới cổng HTTPS
- `tls` — các gói tin giao thức TLS
- `http` — đối chiếu với lưu lượng cổng 80

Quan sát cột Protocol, cột Info và chọn một gói Application Data để xem dữ liệu đã mã hóa.

**Bước 5. Ghi kết quả:** tạo tệp `answer.txt` ghi cổng đích HTTPS và tên giao thức hiển thị trên Wireshark, ví dụ:

`echo "Port: 443, Protocol: TLS" > answer.txt`

**Kiểm tra tiến độ:** `checkwork net-https-identify`

**Kết thúc bài lab:** `stoplab net-https-identify` (tệp zip kết quả được lưu tại vị trí hiển thị bên dưới lệnh).

**Khởi động lại bài lab:** `labtainer -r net-https-identify`

## 5. Phân tích yêu cầu

Hệ thống cung cấp hai máy Linux trên cùng mạng ảo: `client` (cài Wireshark, tshark, curl, openssl) và `server` (nginx hỗ trợ HTTP và HTTPS với chứng chỉ tự ký). Người thực hành lần lượt: bắt gói tin → tạo lưu lượng HTTPS và HTTP → lọc, phân tích → ghi kết quả vào `answer.txt`.

## 6. Thiết kế

| Thành phần | Mô tả |
|---|---|
| `config/start.config` | Khai báo hai container `client`, `server` và mạng ảo `LAN` (172.25.0.0/24) |
| `config/results.config` | Khai báo các kết quả cần ghi nhận |
| `config/goals.config` | Điều kiện chấm điểm tự động |
| `dockerfiles/` | Dockerfile của hai container (nền `labtainer.base2`) |
| `server/_system/` | Cấu hình nginx (cổng 80, 443) và trang web mẫu |
| `server/_bin/fixlocal.sh` | Bật nginx khi container server khởi động |

**Bảng Result**

| Result Tag | Container | File | Field Type | Field ID | Timestamp Type |
|---|---|---|---|---|---|
| capture | client | .bash_history | CONTAINS | wireshark | File |
| https_request | client | .bash_history | CONTAINS | curl -k https://server | File |
| http_request | client | .bash_history | CONTAINS | curl http://server | File |
| answer_port | client | answer.txt | CONTAINS | 443 | File |
| answer_protocol | client | answer.txt | CONTAINS | TLS | File |

- `capture`: đã mở Wireshark bắt gói tin
- `https_request`: đã tạo lưu lượng HTTPS
- `http_request`: đã tạo lưu lượng HTTP đối chiếu
- `answer_port`: xác định đúng cổng HTTPS là 443
- `answer_protocol`: xác định đúng giao thức hiển thị là TLS

## 7. Kết quả mong đợi

Lọc `tcp.port == 443` và `tls` cho thấy: bắt tay ba bước TCP, Client Hello, Server Hello và các bản ghi Application Data đã mã hóa. Lọc `http` cho thấy nội dung Request/Response ở dạng văn bản rõ, khác với dữ liệu mã hóa của HTTPS.
