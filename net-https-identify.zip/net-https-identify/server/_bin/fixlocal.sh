#!/bin/bash
# Chay khi container server khoi dong: kich hoat cau hinh va bat nginx
ln -sf /etc/nginx/sites-available/default /etc/nginx/sites-enabled/default
service nginx start
