# net-https-identify

Bài Lab Labtainer: **Nhận diện lưu lượng HTTPS và cổng 443** (mức độ 1).
Đề tài: Xây dựng các bài Lab trên Labtainer để phát hiện & phân tích các giao thức kết nối mạng — Học viện Công nghệ Bưu chính Viễn thông, Khoa An toàn thông tin.

Sinh viên thực hiện: Đàm Hoàng Đăng (B22DCAT081). Giảng viên hướng dẫn: TS. Quản Trọng Thế.

## Cách chạy

```
git clone https://github.com/<tai-khoan>/<repo>.git
cp -r <repo>/net-https-identify ~/labtainer/trunk/labs/
cd ~/labtainer/trunk/scripts/labtainer-student
labtainer net-https-identify
```
Chỉ sao chép **thư mục `net-https-identify`** vào `labs` (không sao chép README này).

Kiểm tra: `checkwork net-https-identify`; kết thúc: `stoplab net-https-identify`; làm lại: `labtainer -r net-https-identify`.

## Cấu trúc (theo bố cục bài mẫu acl)

```
net-https-identify/
├── config/         start.config, about.txt, keywords.txt, parameter.config
├── instr_config/   results.config, goals.config, pregrade.sh
├── dockerfiles/    Dockerfile của container client và server
├── docs/           hướng dẫn thực hành (PDF) và read_first.txt
├── client/         tệp hướng dẫn trong thư mục home của client
└── server/         cấu hình nginx, trang web mẫu, script khởi động
```
